package domain;

import java.awt.Color;

public class QuickTimeGame extends Game {

	public QuickTimeGame(int size, int especialPercentage) {
		super(size, especialPercentage);
		start(especialPercentage);
	}

	public void start(int especialPercentage) {

	}

}
