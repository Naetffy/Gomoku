package domain;

public class GoldenSquare extends Square {

}
