package domain;

public class TeleportSquare extends Square {

}
