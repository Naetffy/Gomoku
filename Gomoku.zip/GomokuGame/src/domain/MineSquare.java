package domain;

public class MineSquare extends Square {

}
