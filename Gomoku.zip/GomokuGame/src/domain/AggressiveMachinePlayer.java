package domain;

public class AggressiveMachinePlayer extends MachinePlayer {
	public int[] play() {
		return miniMax();
	}

	public int[] miniMax() {
		// Implementar
		return null;
	}
}
