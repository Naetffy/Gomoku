package domain;

import java.awt.Color;

public class LimitedGame extends Game {

	public LimitedGame(int size, int especialPercentage) {
		super(size, especialPercentage);
		start(especialPercentage);
	}

	public void start(int especialPercentage) {

	}
}
