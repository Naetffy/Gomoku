package domain;

import java.awt.Color;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class NormalPlayer extends Player {


	public int[] play() {
		return null;
	}

	
}
