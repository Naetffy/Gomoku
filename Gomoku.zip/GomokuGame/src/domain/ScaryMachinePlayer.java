package domain;

public class ScaryMachinePlayer extends MachinePlayer {
	public int[] play() {
		return miniMax();
	}

	public int[] miniMax() {
		// Implemantar el minimax
		return null;
	}

}
