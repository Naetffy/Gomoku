package domain;

public class ExpertMachinePlayer extends MachinePlayer {

	public int[] play() {
		return miniMax();
	}

	public int[] miniMax() {
		// Implementar miniMax para experta
		return null;
	}

}
