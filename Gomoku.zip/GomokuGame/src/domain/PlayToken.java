package domain;

public interface PlayToken {
	
	public void act();

}
