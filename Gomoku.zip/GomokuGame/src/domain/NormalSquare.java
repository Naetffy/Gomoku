package domain;

public class NormalSquare extends Square {

	public NormalSquare() {
		super();
	}
}
